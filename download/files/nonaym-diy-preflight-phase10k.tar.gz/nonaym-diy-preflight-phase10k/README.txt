Nonaym DIY Preflight Package — Phase 10K

Version:
phase10j-v2.1

Purpose:
Read-only hardware compatibility preflight for Nonaym DIY.

This package does not install software, change DNS, change networking,
format disks, start services, or modify firewall rules.

Run:

chmod +x nonaym-diy-preflight.sh
./nonaym-diy-preflight.sh

Expected output includes:

NONAYM DIY RESULT: PASS
NONAYM DIY RESULT: CAUTION
or
NONAYM DIY RESULT: FAIL

Reports are saved under:

./reports/
