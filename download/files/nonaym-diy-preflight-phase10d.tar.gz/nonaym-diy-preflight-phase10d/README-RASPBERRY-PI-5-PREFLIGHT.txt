Nonaym DIY Phase 10D — Raspberry Pi 5 Preflight Test

Purpose:
Run a read-only hardware inventory on a Raspberry Pi 5 and confirm the correct Nonaym DIY profile.

This package does not install Nonaym.
This package does not install Docker.
This package does not install Technitium.
This package does not change DNS.
This package does not format disks.
This package does not change router settings.

Expected Raspberry Pi 5 result:
- Architecture: aarch64
- Raspberry Pi detected: yes
- Recommended Profile: Raspberry Pi / ARM64 Profile

Run:

chmod +x nonaym-diy-preflight.sh
./nonaym-diy-preflight.sh

After it runs, check the generated report under:

reports/

Save or copy the report back for Phase 10D documentation.
